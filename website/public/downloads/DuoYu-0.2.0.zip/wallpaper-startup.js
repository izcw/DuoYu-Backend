// Resolve the fallback before first paint, independently of preview storage.
(() => {
  const root = document.documentElement;
  let dark;
  let light;
  let timer;
  try {
    dark = window.matchMedia('(prefers-color-scheme: dark)');
    light = window.matchMedia('(prefers-color-scheme: light)');
  } catch {
    // Unsupported media queries fall back to local time.
  }
  function update() {
    clearTimeout(timer);
    const now = new Date();
    const systemKnown = dark?.matches || light?.matches;
    const systemDark = systemKnown
      ? dark.matches
      : now.getHours() < 7 || now.getHours() >= 19;
    const saved = localStorage.getItem('duoyu-theme');
    const preference = saved === 'dark' || saved === 'light' ? saved : 'auto';
    const isDark = preference === 'auto' ? systemDark : preference === 'dark';
    const mode = isDark ? 'dark' : 'light';
    root.dataset.themePreference = preference;
    const color = isDark ? '#000000' : '#ffffff';
    root.dataset.fallbackTheme = mode;
    root.style.setProperty('--wallpaper-fallback', color);
    root.style.backgroundColor = color;
    root.style.colorScheme = mode;
    window.dispatchEvent(new Event('duoyu-theme-applied'));
    if (preference === 'auto' && !systemKnown) {
      const next = new Date(now);
      next.setHours(
        now.getHours() < 7 ? 7 : now.getHours() < 19 ? 19 : 31,
        0,
        0,
        0,
      );
      timer = setTimeout(update, next.getTime() - now.getTime());
    }
  }
  update();
  window.addEventListener('duoyu-theme-change', update);
  window.addEventListener('storage', (event) => {
    if (event.key === 'duoyu-theme' || event.key === null) update();
  });
  dark?.addEventListener?.('change', update);
  light?.addEventListener?.('change', update);
  document.addEventListener('visibilitychange', () => {
    if (!document.hidden) update();
  });
})();

// Runs before the app bundle. Only a small preview is stored synchronously;
// Dexie remains the source of truth for the full-resolution wallpaper.
(async () => {
  try {
    // Match accountStorage before the app and database have initialized.
    const account = localStorage.getItem('duoyu-sync-account');
    if (account) {
      const owner = (await chrome.storage.session.get('duoyuAuthSession')).duoyuAuthSession?.account;
      if (!owner) return;
      const digest = await crypto.subtle.digest('SHA-256',new TextEncoder().encode(owner.issuer+'\0'+owner.sub));
      if (Array.from(new Uint8Array(digest), n=>n.toString(16).padStart(2,'0')).join('') !== account) return;
    }
    const prefix = account ? `account:${account}:` : 'guest-template:';
    const desktop = localStorage.getItem(`${prefix}duoyu-device-desktop`) || 'default';
    const key = desktop === 'default' ? 'duoyu:wallpaper-preview' : 'duoyu:desktop-preview:' + desktop;
    const raw = localStorage.getItem(prefix + key);
    if (!raw || raw.length > 180000) return;
    const preview = JSON.parse(raw);
    if (
      desktop === 'default' && localStorage.getItem(`${prefix}duoyu-wallpaper-mode`) === 'custom' &&
      !preview.sourceUrl?.startsWith('local:')
    )
      return;
    if (
      typeof preview.data !== 'string' ||
      !/^data:image\/jpeg;base64,[A-Za-z0-9+/=]+$/.test(preview.data)
    )
      return;
    const root = document.documentElement;
    root.style.backgroundImage = `url("${preview.data}")`;
    root.style.backgroundSize = 'cover';
    root.style.backgroundPosition = 'center';
    root.style.backgroundAttachment = 'fixed';
    root.style.backgroundRepeat = 'no-repeat';
    root.dataset.wallpaperPreview = 'ready';
  } catch {
    // Invalid or unavailable preview storage must never block the new tab.
  }
})();
